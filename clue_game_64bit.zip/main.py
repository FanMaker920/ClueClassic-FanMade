import pygame
from game.board import Board
from game.game_logic import Game

pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Clue-Inspired Game")
clock = pygame.time.Clock()

board = Board(screen)
game = Game(board)

running = True
while running:
    screen.fill((255, 255, 255))
    board.draw()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    game.update()
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
