# How to Run the Clue-Inspired Game (64-bit)

This is a cross-platform Clue-style mystery game written in Python.

## Requirements
- Python 3.8 or later (64-bit)
- Pygame (installed via pip)

## Setup Instructions
1. Open a terminal or command prompt.
2. Navigate to the game folder:
   ```bash
   cd path/to/clue_game
   ```

3. (Optional) Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate   # Windows: venv\Scripts\activate
   ```

4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

5. Run the game:
   ```bash
   python main.py
   ```

## macOS Notes
- Works on Intel and Apple Silicon (M1/M2) with Python 3.9+ (64-bit).
- You may need to allow Python and Pygame in `System Settings > Security`.

## Troubleshooting
- If Pygame fails to run:
   ```bash
   pip install pygame
   ```
