class AILogic:
    def make_move(self, player):
        print(f"{player.name} is thinking...")
